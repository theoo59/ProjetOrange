<h1>Liste des techniciens</h1>
<ul>
    <?php $__currentLoopData = $technicien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($technicien->nom); ?> <?php echo e($technicien->prenom); ?> - <?php echo e($technicien->numerotelephone); ?> - <?php echo e($technicien->astreinte); ?> - <?php echo e($technicien->Secteur_idSecteur); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\wamp64\www\ProjetOrange\resources\views/technicien/index.blade.php ENDPATH**/ ?>