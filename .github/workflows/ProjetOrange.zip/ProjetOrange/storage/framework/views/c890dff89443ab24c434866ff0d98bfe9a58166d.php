<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chambres de Raccordement</title>
    <style>
        body {
            background-color: black;
            color: #FF7900;
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        h1 {
            color: #FF7900;
            margin-bottom: 20px;
        }

        .table-container {
            flex-grow: 1; /* Permet au tableau de s'étendre */
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
        }

        table {
            width: 80%;
            max-width: 800px;
            border-collapse: collapse;
            background-color: white;
            color: black;
            border-radius: 5px;
            overflow: hidden;
            margin: auto;
        }

        th, td {
            padding: 12px;
            border: 1px solid #FF7900;
            text-align: center;
        }

        th {
            background-color: #FF7900;
            color: white;
        }

        tr:hover {
            background-color: #f2f2f2;
        }

        /* Footer avec le logo */
        .footer {
            text-align: center;
            padding: 10px;
            margin-top: auto; /* Place le footer en bas */
        }

        .footer img {
            width: 100px; /* Taille du logo */
        }

        @media  screen and (max-width: 600px) {
            table {
                width: 100%;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

    <h1>Liste des Chambres de Raccordement</h1>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th>Désactivation</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $chambres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chambre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($chambre->idChambre); ?></td>
                    <td><?php echo e($chambre->latitude ?? 'N/A'); ?></td>
                    <td><?php echo e($chambre->longitude ?? 'N/A'); ?></td>
                    <td>
                        <a href="<?php echo e(route('chambre.desactiver', ['id' => $chambre->idChambre])); ?>" class="btn btn-warning">
                            Désactiver
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Logo Orange en bas -->
    <div class="footer">
        <img src="<?php echo e(asset('images/orange-logo.png')); ?>" alt="Logo Orange">
    </div>

</body>
</html>
<?php /**PATH C:\wamp64\www\ProjetOrange\resources\views/technicienDashboard.blade.php ENDPATH**/ ?>