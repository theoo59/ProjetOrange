<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: black;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-box {
            background-color: #222;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(255, 255, 255, 0.1);
            text-align: center;
        }
        .login-box input {
            background-color: #444;
            border: none;
            color: white;
        }
        .login-box input::placeholder {
            color: #bbb;
        }
        .btn-orange {
            background-color: #FF7900;
            border: none;
            color: black;
        }
        .btn-orange:hover {
            background-color: darkorange;
        }
        .logo {
            width: 100px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <img src="<?php echo e(asset('images/orange-logo.png')); ?>" alt="Logo" class="logo">
        <h2 class="mb-3">Connexion</h2>

        <!-- Affichage des erreurs -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <input type="text" name="ldap" class="form-control" placeholder="Identifiant LDAP (8 chiffres)" required pattern="\d{8}">
            </div>
            <div class="mb-3">
                <input type="password" name="password" class="form-control" placeholder="Mot de passe" required>
            </div>
            <button type="submit" class="btn btn-orange w-100">Se connecter</button>
        </form>
    </div>
</body>
</html>


<?php /**PATH C:\wamp64\www\ProjetOrange\resources\views/auth/login.blade.php ENDPATH**/ ?>