<h1>Coordonnées de la chambre en effraction</h1>

<?php if($chambre): ?>
    <p>Nom de la chambre : <?php echo e($chambre->idChambre); ?></p>
    <p>Latitude : <?php echo e($chambre->latitude); ?></p>
    <p>Longitude : <?php echo e($chambre->longitude); ?></p>
<?php else: ?>
    <p>Aucune chambre en effraction trouvée.</p>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\ProjetOrange\resources\views/chambre/index.blade.php ENDPATH**/ ?>