<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\TechnicienAuthController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\AlarmeController;
use App\Http\Controllers\ChambreController;
use App\Http\Controllers\CompteRenduController;

//------------------------------ Login---------------------------------------------------------------
// Formulaire de connexion unique
Route::get('login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('login', [AuthController::class, 'login'])->name('login.post');

// Tableau de bord Administrateur
Route::get('/dashboard', [DashboardController::class, 'index'])->middleware('auth:web')->name('dashboard');

// Tableau de bord Technicien
Route::get('/technicien/dashboard', [TechnicienAuthController::class, 'index'])
    ->middleware('auth:technicien') // Vérifie si l'utilisateur est un technicien
    ->name('technicienDashboard');

// Déconnexion
Route::post('logout', [AuthController::class, 'logout'])->name('logout');
Route::post('/technicien/logout', [AuthController::class, 'logout'])
    ->middleware('auth:technicien')
    ->name('technicien.logout');

// --------------------------- Alarme --------------------------------------------------------------------
Route::post('/alarme/desactiver', [AlarmeController::class, 'desactiver'])->name('alarme.desactiver');

// Groupe de routes protégées par l'authentification du technicien
Route::middleware(['auth:technicien'])->group(function () {
    Route::get('/technicien/dashboard', [TechnicienAuthController::class, 'index'])->name('technicienDashboard');
    
    // Route pour afficher la page de désactivation de la chambre
    Route::get('/chambre/desactiver/{id}', [ChambreController::class, 'showDesactivationPage'])
        ->name('chambre.desactiver');
    
    // Route pour effectuer la désactivation de la chambre
    Route::post('/chambre/desactiver/{id}', [ChambreController::class, 'desactiver'])
        ->name('chambre.desactiver.post');
});

// Route pour afficher la page de compte rendu
Route::get('/compte-rendu/{id}', [CompteRenduController::class, 'show'])->name('compterendu');

Route::get('/compterendu/{id}', [CompteRenduController::class, 'show'])->name('compterendu');
Route::post('/compterendu/{id}', [CompteRenduController::class, 'store'])->name('compterendu.store');




?>
